package com.example.service;

import java.util.List;

import com.example.entity.UserEntity;

public interface UserService {

	UserEntity saveUserEntity(UserEntity entity);

	List<UserEntity> fetchUserEntityList();

	UserEntity fetchUserEntityId(Long id);

	void deleteUserEntityId(Long id);

}
