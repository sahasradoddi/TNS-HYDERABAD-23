package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.UserEntity;
import com.example.repository.UserRepository;



@Service
public class UserServiceImple implements UserService{
	
	@Autowired
	private UserRepository repository;

	@Override
	public UserEntity saveUserEntity(UserEntity entity) {
		// TODO Auto-generated method stub
		return repository.save(entity);
	}

	@Override
	public List<UserEntity> fetchUserEntityList() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public UserEntity fetchUserEntityId(Long id) {
		// TODO Auto-generated method stub
		return repository.findById(id).get();
		
	}

	@Override
	public void deleteUserEntityId(Long id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);;
		
	}

	
}
